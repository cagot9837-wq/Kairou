# Workflow autossuficiente para gerar APK Android

Este pacote tem um único workflow principal. Ele gera o projeto Android no runner do GitHub; você não precisa enviar manualmente arquivos `app/`, `build.gradle` ou `settings.gradle`.

## Instalação no GitHub
1. Extraia o ZIP.
2. No repositório, crie o caminho `.github/workflows/android.yml` e coloque lá o arquivo `android.yml`. O nome e o caminho precisam ser exatamente esses.
3. Salve o arquivo na branch padrão do repositório (normalmente `main`).
4. Abra **Actions** → **Gerar APK Android** → **Run workflow**. Também executa a cada push na branch `main` ou `master`.
5. Quando a execução terminar com sucesso, baixe o artefato `pool-trajectory-debug-apk` na parte inferior da página da execução.

O workflow instala Java 17, Android SDK (API 35) e Gradle 8.7, gera o código de um app Android de calculadora manual de trajetória e compila o APK. Ele não detecta automaticamente bolas nem altera o jogo 8 Ball Pool.

Se falhar, a execução da Actions mostrará a etapa que falhou; quando houver relatórios de compilação, o workflow tenta publicá-los no artefato `android-build-diagnostics`.
