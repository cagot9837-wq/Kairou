# Correção do workflow Android

Copie `android.yml` para `.github/workflows/android.yml` no repositório.

Este workflow:
- configura Java 17 e Android SDK;
- aceita licenças em modo não interativo;
- instala platform-tools, Android Platform 35 e Build Tools 35.0.0;
- verifica se os arquivos Gradle do projeto existem;
- compila e publica o APK debug.

Importante: este arquivo compila o projeto Android que está no repositório. Ele não gera os arquivos Kotlin/Gradle ausentes. Se a etapa "Verificar estrutura do projeto" falhar, envie o projeto Android completo para a raiz do repositório.
