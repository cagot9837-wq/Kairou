# 8 Ball Pool Assistant - App Completo

Assistente de mira para 8 Ball Pool com detecção de bolas, cálculo de trajetória e overlay em tempo real.

## 📋 Requisitos

- Android SDK 21+ (compilado pra Android 34)
- Android Studio 2023.1+
- Java 11+
- OpenCV4Android 4.8.0

## 🚀 Instalação e Compilação

### 1. Clone ou baixe o projeto

```bash
unzip 8BallPoolAssistant.zip
cd 8BallPoolAssistant
```

### 2. Configure o Android Studio

Abra o projeto em Android Studio. O Gradle vai baixar as dependências automaticamente.

### 3. Compile e rode

```bash
./gradlew build
./gradlew installDebug
```

Ou direto no Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)

### 4. Conceda permissões

No telefone:
- Configurações > Apps > 8 Ball Pool Assistant > Permissões
- Ativar: "Aparecer sobre outros apps" e "Usar câmera"

## 🎮 Como Usar

1. Abra o app
2. Clique em "Iniciar Assistência"
3. Selecione a janela de captura do 8 Ball Pool
4. O overlay aparece automaticamente com as trajetórias

## 📁 Estrutura do Projeto

```
8BallPoolAssistant/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── kotlin/com/ballpool/assistant/
│   │       │   ├── MainActivity.kt
│   │       │   ├── OverlayService.kt
│   │       │   ├── ScreenCaptureManager.kt
│   │       │   ├── BallDetector.kt
│   │       │   ├── TrajectoryCalculator.kt
│   │       │   ├── OverlayView.kt
│   │       │   └── Utils.kt
│   │       └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## ⚙️ Configurações

### Calibração da Mesa

Edite em `TrajectoryCalculator.kt`:

```kotlin
private fun tableBounds(): RectF {
    return RectF(50f, 200f, 1030f, 1800f)  // Ajuste para sua resolução
}
```

### Cores de Detecção

Em `BallDetector.kt`, na função `classifyBallColor()`:

```kotlin
return when {
    value > 200 && saturation < 30 -> BallColor.WHITE
    value < 50 -> BallColor.BLACK
    saturation < 50 -> BallColor.WHITE
    else -> if (hue < 60) BallColor.SOLID else BallColor.STRIPED
}
```

## 🔧 Troubleshooting

### "Permission denied" ao iniciar captura
- Verifique se a permissão `SYSTEM_ALERT_WINDOW` foi concedida
- Tente ativar em Configurações > Apps > Permissões especiais

### Overlay não aparece
- Reinicie o app
- Limpe o cache: `./gradlew clean`
- Recompile: `./gradlew build`

### Detecção lenta
- Reduza a resolução da captura em `ScreenCaptureManager.kt`
- Aumente o intervalo entre frames

### Trajetória imprecisa
- Calibre os `tableBounds()` corretamente
- Ajuste os parâmetros do `HoughCircles` em `BallDetector.kt`

## 📦 Dependências

- OpenCV 4.8.0 (detecção de bolas)
- AndroidX AppCompat (compatibilidade)
- Kotlin Coroutines (async/processamento)

## ⚖️ Avisos Legais

Este app NÃO:
- Modifica arquivos do jogo
- Bypassa mecanismos de segurança
- Funciona com anti-cheat em tempo real
- É garantido que funcione em todas as versões do 8 Ball Pool

Use por sua conta e risco.

## 📝 License

MIT License - Sinta-se livre pra modificar e usar.

---

Desenvolvido com ☕ e muito código.
