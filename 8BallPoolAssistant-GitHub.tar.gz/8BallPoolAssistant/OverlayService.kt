package com.ballpool.assistant

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.WindowManager
import kotlinx.coroutines.*

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: OverlayView
    private var screenCaptureManager: ScreenCaptureManager? = null
    private val ballDetector = BallDetector()
    private val trajectoryCalc = TrajectoryCalculator()

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        setupOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")

        if (resultCode > 0 && data != null) {
            startAssisting(resultCode, data)
        }

        return START_STICKY
    }

    private fun setupOverlay() {
        overlayView = OverlayView(this)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )

        windowManager.addView(overlayView, params)
    }

    private fun startAssisting(resultCode: Int, data: Intent) {
        screenCaptureManager = ScreenCaptureManager(this)

        screenCaptureManager?.startCapture(resultCode, data) { bitmap ->
            serviceScope.launch {
                try {
                    val balls = ballDetector.detect(bitmap)

                    if (balls.size >= 2) {
                        val cueBall = balls.firstOrNull { it.color == BallColor.WHITE }
                            ?: balls.maxByOrNull { it.radius }
                        val targetBall = balls.firstOrNull {
                            it.color != BallColor.WHITE && it != cueBall
                        }

                        if (cueBall != null && targetBall != null) {
                            val aimDir = android.graphics.PointF(
                                (targetBall.center.x - cueBall.center.x).toFloat(),
                                (targetBall.center.y - cueBall.center.y).toFloat()
                            )

                            val result = trajectoryCalc.calculate(cueBall, targetBall, aimDir)

                            Handler(Looper.getMainLooper()).post {
                                overlayView.update(result, balls)
                            }
                        }
                    }

                    bitmap.recycle()

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        screenCaptureManager?.stop()
        windowManager.removeView(overlayView)
        serviceScope.cancel()
    }
}
