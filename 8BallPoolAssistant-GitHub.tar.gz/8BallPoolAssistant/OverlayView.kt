package com.ballpool.assistant

import android.content.Context
import android.graphics.*
import android.view.View

class OverlayView(context: Context) : View(context) {

    var trajectoryResult: TrajectoryResult? = null
    var detectedBalls: List<Ball> = emptyList()

    private val cuePath = Paint().apply {
        color = Color.parseColor("#00FF88")
        strokeWidth = 4f
        style = Paint.Style.STROKE
        isAntiAlias = true
        pathEffect = DashPathEffect(floatArrayOf(20f, 10f), 0f)
    }

    private val targetPath = Paint().apply {
        color = Color.parseColor("#FF4444")
        strokeWidth = 4f
        style = Paint.Style.STROKE
        isAntiAlias = true
        pathEffect = DashPathEffect(floatArrayOf(15f, 8f), 0f)
    }

    private val contactPaint = Paint().apply {
        color = Color.YELLOW
        style = Paint.Style.FILL
    }

    private val contactBorder = Paint().apply {
        color = Color.BLACK
        strokeWidth = 2f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val anglePaint = Paint().apply {
        color = Color.WHITE
        textSize = 36f
        isAntiAlias = true
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        setShadowLayer(5f, 2f, 2f, Color.BLACK)
    }

    private val ballCirclePaint = Paint().apply {
        color = Color.TRANSPARENT
        strokeWidth = 2f
        style = Paint.Style.STROKE
        isAntiAlias = true
    }

    private val whiteBallPaint = Paint().apply {
        color = Color.parseColor("#CCCCFF")
    }

    private val solidBallPaint = Paint().apply {
        color = Color.parseColor("#FF6666")
    }

    private val stripedBallPaint = Paint().apply {
        color = Color.parseColor("#FFCC66")
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Desenha bolas detectadas
        for (ball in detectedBalls) {
            drawBall(canvas, ball)
        }

        val result = trajectoryResult ?: return

        // Desenha trajetória da bola branca
        drawPath(canvas, result.cueBallPath, cuePath)

        // Desenha trajetória da bola alvo
        drawPath(canvas, result.targetBallPath, targetPath)

        // Ponto de contato
        canvas.drawCircle(
            result.contactPoint.x,
            result.contactPoint.y,
            14f,
            contactPaint
        )
        canvas.drawCircle(
            result.contactPoint.x,
            result.contactPoint.y,
            14f,
            contactBorder
        )

        // HUD de ângulos
        drawHUD(canvas, result)
    }

    private fun drawBall(canvas: Canvas, ball: Ball) {
        val paint = when (ball.color) {
            BallColor.WHITE -> whiteBallPaint
            BallColor.SOLID -> solidBallPaint
            BallColor.STRIPED -> stripedBallPaint
            BallColor.BLACK -> Paint().apply {
                color = Color.BLACK
            }
            else -> Paint().apply {
                color = Color.GRAY
            }
        }

        canvas.drawCircle(
            ball.center.x.toFloat(),
            ball.center.y.toFloat(),
            ball.radius.toFloat(),
            paint
        )

        ballCirclePaint.color = when (ball.color) {
            BallColor.WHITE -> Color.parseColor("#0088FF")
            BallColor.SOLID -> Color.parseColor("#FF0000")
            BallColor.STRIPED -> Color.parseColor("#FFAA00")
            BallColor.BLACK -> Color.parseColor("#00FF00")
            else -> Color.GRAY
        }

        canvas.drawCircle(
            ball.center.x.toFloat(),
            ball.center.y.toFloat(),
            ball.radius.toFloat(),
            ballCirclePaint
        )
    }

    private fun drawPath(canvas: Canvas, points: List<PointF>, paint: Paint) {
        if (points.size < 2) return

        for (i in 0 until points.size - 1) {
            canvas.drawLine(
                points[i].x,
                points[i].y,
                points[i + 1].x,
                points[i + 1].y,
                paint
            )
        }
    }

    private fun drawHUD(canvas: Canvas, result: TrajectoryResult) {
        val padding = 30f
        val lineHeight = 50f
        var y = padding

        // Background para melhor leitura
        val bgPaint = Paint().apply {
            color = Color.argb(200, 0, 0, 0)
        }

        canvas.drawRect(
            padding - 10f,
            y - 35f,
            300f,
            y + lineHeight * 3,
            bgPaint
        )

        // Ângulos
        canvas.drawText(
            "IN: ${result.angleIn.toInt()}°",
            padding,
            y + 40f,
            anglePaint
        )

        canvas.drawText(
            "OUT: ${result.angleOut.toInt()}°",
            padding,
            y + 90f,
            anglePaint
        )

        canvas.drawText(
            "CONTATO",
            padding,
            y + 140f,
            anglePaint.apply { textSize = 28f }
        )
    }

    fun update(result: TrajectoryResult, balls: List<Ball> = emptyList()) {
        trajectoryResult = result
        detectedBalls = balls
        invalidate()
    }

    fun clearTrajectory() {
        trajectoryResult = null
        invalidate()
    }
}
