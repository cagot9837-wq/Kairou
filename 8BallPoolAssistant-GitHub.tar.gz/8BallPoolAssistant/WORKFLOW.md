# Workflow do Projeto 8 Ball Pool Assistant

## 📋 Estrutura de Diretórios

```
8BallPoolAssistant/
├── app/
│   └── src/
│       └── main/
│           ├── kotlin/com/ballpool/assistant/
│           │   ├── MainActivity.kt
│           │   ├── OverlayService.kt
│           │   ├── ScreenCaptureManager.kt
│           │   ├── BallDetector.kt
│           │   ├── TrajectoryCalculator.kt
│           │   └── OverlayView.kt
│           ├── res/
│           │   ├── layout/
│           │   │   └── activity_main.xml
│           │   ├── values/
│           │   │   └── colors.xml
│           │   └── drawable/
│           │       └── (ícones e backgrounds)
│           └── AndroidManifest.xml
├── build.gradle.kts
├── settings.gradle.kts
├── README.md
└── WORKFLOW.md
```

## 🔄 Fluxo de Execução

### 1. Inicialização da App

```
MainActivity.onCreate()
    ↓
setupUI()
    ↓
Aguarda clique do usuário em "Iniciar Assistência"
```

### 2. Captura de Tela

```
startAssistance()
    ↓
Solicita MediaProjection (permissão do sistema)
    ↓
OverlayService.onStartCommand()
    ↓
ScreenCaptureManager.startCapture()
    ↓
ImageReader.setOnImageAvailableListener()
    ↓
Loop contínuo de frames
```

### 3. Detecção de Bolas

```
Frame capturado
    ↓
BallDetector.detect(bitmap)
    ↓
Conversão para Mat (OpenCV)
    ↓
Gaussian Blur
    ↓
HoughCircles (detecção)
    ↓
Classificação de cores (HSV)
    ↓
Retorna List<Ball>
```

### 4. Cálculo de Trajetória

```
Bolas detectadas
    ↓
Identifica bola branca (CUE)
    ↓
Identifica bola alvo (TARGET)
    ↓
TrajectoryCalculator.calculate()
    ├── Calcula ponto de contato
    ├── Simula trajetória da bola branca
    ├── Simula trajetória da bola alvo
    ├── Calcula ângulos de entrada/saída
    └── Retorna TrajectoryResult
```

### 5. Renderização do Overlay

```
TrajectoryResult obtido
    ↓
OverlayView.update()
    ↓
onDraw() chamado
    ├── Desenha bolas detectadas
    ├── Desenha trajetória da branca (linha verde tracejada)
    ├── Desenha trajetória do alvo (linha vermelha tracejada)
    ├── Desenha ponto de contato (círculo amarelo)
    └── Desenha HUD com ângulos
```

## 🎯 Ciclo de Processamento

O app funciona em um loop contínuo:

```
1. ScreenCaptureManager captura frame
2. BallDetector analisa frame
3. TrajectoryCalculator calcula trajetória
4. OverlayView renderiza resultado
5. Volta ao passo 1
```

**Latência esperada:** ~100-300ms por frame (depende do dispositivo)

## 🔧 Componentes Principais

### MainActivity
- Gerencia UI
- Solicita permissões
- Inicia/para o OverlayService

### OverlayService
- Coordena captura e processamento
- Roda em background como foreground service
- Gerencia ciclo de vida da assistência

### ScreenCaptureManager
- Usa MediaProjection API
- Captura frames da tela
- Envia frames para callback

### BallDetector
- Usa OpenCV para detectar círculos
- Classifica cores das bolas
- Retorna lista de bolas detectadas

### TrajectoryCalculator
- Calcula física de colisão
- Simula trajetória com reflexão nas bordas
- Retorna dados de colisão e trajetórias

### OverlayView
- Renderiza trajetórias
- Desenha bolas detectadas
- Exibe HUD com informações

## 📱 Permissões Necessárias

```xml
android.permission.SYSTEM_ALERT_WINDOW
android.permission.FOREGROUND_SERVICE
android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION
android.permission.CAMERA
```

## ⚙️ Calibração Necessária

### 1. Dimensões da Mesa
Edite em `TrajectoryCalculator.kt`:

```kotlin
private fun tableBounds(): RectF {
    return RectF(50f, 200f, 1030f, 1800f)
}
```

Ajuste os valores para sua resolução de tela.

### 2. Parâmetros do HoughCircles
Em `BallDetector.kt`:

```kotlin
Imgproc.HoughCircles(
    gray, circles,
    Imgproc.HOUGH_GRADIENT,
    1.0,      // dp - razão inversa da acumulação
    30.0,     // minDist - distância mínima entre centros
    100.0,    // param1 - limite superior de Canny
    30.0,     // param2 - threshold do acumulador
    8,        // minRadius
    50        // maxRadius
)
```

Ajuste `minRadius` e `maxRadius` para o tamanho das bolas no seu dispositivo.

### 3. Classificação de Cores
Em `BallDetector.kt`, método `classifyBallColor()`:

```kotlin
return when {
    value > 200 && saturation < 50 -> BallColor.WHITE
    value < 80 -> BallColor.BLACK
    saturation < 40 -> BallColor.WHITE
    hue in 0.0..30.0 || hue in 330.0..360.0 -> BallColor.SOLID
    else -> BallColor.STRIPED
}
```

Ajuste os valores de HSV conforme necessário.

## 🚀 Build e Deploy

### Via Gradle (CLI)

```bash
# Build debug APK
./gradlew assembleDebug

# Build release APK
./gradlew assembleRelease

# Instalar em dispositivo
./gradlew installDebug

# Clean
./gradlew clean
```

### Via Android Studio

1. Abra o projeto em Android Studio
2. Build > Build Bundle(s) / APK(s) > Build APK(s)
3. Acompanhe a compilação na aba "Build"
4. APK gerado em `app/build/outputs/apk/debug/`

## 🔍 Debug e Logging

Para adicionar logs:

```kotlin
import android.util.Log

Log.d("BallDetector", "Detected ${balls.size} balls")
Log.i("OverlayService", "Trajectory calculated")
Log.e("ScreenCapture", "Error: ${e.message}")
```

Visualize os logs via Android Studio: View > Tool Windows > Logcat

## 📊 Performance

- **Target FPS:** 30-60
- **CPU Usage:** ~10-30% (varia com resolução)
- **Memory:** ~50-200 MB
- **Latência de resposta:** ~100-300ms

Para otimizar:
1. Reduza resolução da captura
2. Aumente intervalo entre frames
3. Simplifique parâmetros do HoughCircles

## 🐛 Troubleshooting

| Problema | Solução |
|----------|---------|
| Overlay não aparece | Conceda permissão SYSTEM_ALERT_WINDOW em Settings |
| App crashes | Verifique logs em Logcat |
| Detecção lenta | Ajuste HoughCircles ou reduza resolução |
| Trajetória imprecisa | Calibre tableBounds() e parâmetros de cor |
| Muita latência | Reduza SIMULATION_STEPS em TrajectoryCalculator |

## 📝 Próximas Melhorias

- [ ] Calibração automática de mesa
- [ ] Detecção de spin/efeito
- [ ] Predicção de caçapas
- [ ] Histórico de jogadas
- [ ] Suporte a múltiplos níveis de dificuldade
- [ ] Analytics de desempenho

---

**Desenvolvido com ❤️ por LO**
