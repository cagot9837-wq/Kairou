package com.ballpool.assistant

import android.graphics.PointF
import android.graphics.RectF
import kotlin.math.*

data class TrajectoryResult(
    val cueBallPath: List<PointF>,
    val targetBallPath: List<PointF>,
    val contactPoint: PointF,
    val angleIn: Float,
    val angleOut: Float
)

class TrajectoryCalculator {

    companion object {
        private const val TABLE_FRICTION = 0.98f
        private const val MAX_BOUNCES = 4
        private const val SIMULATION_STEPS = 100
    }

    fun calculate(
        cueBall: Ball,
        targetBall: Ball,
        aimDirection: PointF
    ): TrajectoryResult {

        val cuePath = mutableListOf<PointF>()
        val targetPath = mutableListOf<PointF>()

        val contactPoint = calculateContactPoint(cueBall, targetBall)

        val currentPos = PointF(cueBall.center.x.toFloat(), cueBall.center.y.toFloat())
        cuePath.add(PointF(currentPos.x, currentPos.y))
        cuePath.add(contactPoint)

        val collisionAngle = calculateCollisionAngle(cueBall, targetBall)
        val angleIn = Math.toDegrees(
            atan2(aimDirection.y.toDouble(), aimDirection.x.toDouble())
        ).toFloat()

        val targetVector = normalizeVector(
            PointF(
                (targetBall.center.x - cueBall.center.x).toFloat(),
                (targetBall.center.y - cueBall.center.y).toFloat()
            )
        )

        val targetPos = PointF(targetBall.center.x.toFloat(), targetBall.center.y.toFloat())
        targetPath.add(PointF(targetPos.x, targetPos.y))

        simulatePath(targetPos, targetVector, targetPath, tableBounds())

        val angleOut = Math.toDegrees(
            atan2(targetVector.y.toDouble(), targetVector.x.toDouble())
        ).toFloat()

        return TrajectoryResult(cuePath, targetPath, contactPoint, angleIn, angleOut)
    }

    private fun simulatePath(
        start: PointF,
        direction: PointF,
        path: MutableList<PointF>,
        bounds: RectF
    ) {
        var pos = PointF(start.x, start.y)
        var dir = PointF(direction.x, direction.y)
        var speed = 1f
        var bounces = 0

        for (step in 0 until SIMULATION_STEPS) {
            if (speed < 0.1f || bounces >= MAX_BOUNCES) break

            val nextPos = PointF(pos.x + dir.x * 15f, pos.y + dir.y * 15f)

            val reflection = checkBounce(pos, nextPos, dir, bounds)
            path.add(reflection.first)

            pos = reflection.first
            dir = reflection.second
            speed *= TABLE_FRICTION

            if (reflection.third) bounces++
        }
    }

    private fun checkBounce(
        from: PointF,
        to: PointF,
        direction: PointF,
        bounds: RectF
    ): Triple<PointF, PointF, Boolean> {

        var newDir = PointF(direction.x, direction.y)
        var bounced = false

        var x = to.x
        var y = to.y

        if (x < bounds.left || x > bounds.right) {
            newDir.x = -newDir.x
            bounced = true
            x = x.coerceIn(bounds.left, bounds.right)
        }

        if (y < bounds.top || y > bounds.bottom) {
            newDir.y = -newDir.y
            bounced = true
            y = y.coerceIn(bounds.top, bounds.bottom)
        }

        val clampedPos = PointF(x, y)
        return Triple(clampedPos, newDir, bounced)
    }

    private fun calculateContactPoint(cue: Ball, target: Ball): PointF {
        val dx = (target.center.x - cue.center.x).toFloat()
        val dy = (target.center.y - cue.center.y).toFloat()
        val dist = sqrt((dx * dx + dy * dy).toDouble()).toFloat()

        return if (dist > 0) {
            val ratio = (dist - cue.radius.toFloat() - target.radius.toFloat()) / dist
            PointF(
                cue.center.x.toFloat() + dx * ratio,
                cue.center.y.toFloat() + dy * ratio
            )
        } else {
            PointF(cue.center.x.toFloat(), cue.center.y.toFloat())
        }
    }

    private fun calculateCollisionAngle(cue: Ball, target: Ball): Float {
        val dx = (target.center.x - cue.center.x).toFloat()
        val dy = (target.center.y - cue.center.y).toFloat()
        return Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
    }

    private fun normalizeVector(v: PointF): PointF {
        val len = sqrt((v.x * v.x + v.y * v.y).toDouble()).toFloat()
        return if (len > 0) {
            PointF(v.x / len, v.y / len)
        } else {
            PointF(0f, 0f)
        }
    }

    private fun tableBounds(): RectF {
        // Ajuste para sua resolução de tela
        return RectF(50f, 200f, 1030f, 1800f)
    }
}
