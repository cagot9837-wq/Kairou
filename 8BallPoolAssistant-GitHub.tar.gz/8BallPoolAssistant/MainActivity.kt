package com.ballpool.assistant

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_MEDIA_PROJECTION = 1001
    }

    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private var isRunning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        startButton = findViewById(R.id.startButton)

        startButton.setOnClickListener {
            if (!isRunning) {
                startAssistance()
            } else {
                stopAssistance()
            }
        }

        updateStatus("Pronto para iniciar")
    }

    private fun startAssistance() {
        updateStatus("Solicitando permissão de captura...")

        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val intent = manager.createScreenCaptureIntent()
        startActivityForResult(intent, REQUEST_MEDIA_PROJECTION)
    }

    private fun stopAssistance() {
        stopService(Intent(this, OverlayService::class.java))
        isRunning = false
        updateStatus("Parado")
        startButton.text = "Iniciar Assistência"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                updateStatus("Captura iniciada... Iniciando assistência")

                val serviceIntent = Intent(this, OverlayService::class.java).apply {
                    putExtra("resultCode", resultCode)
                    putExtra("data", data)
                }

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }

                isRunning = true
                startButton.text = "Parar Assistência"
                updateStatus("Assistência rodando!")

            } else {
                updateStatus("Permissão negada")
            }
        }
    }

    private fun updateStatus(message: String) {
        statusText.text = message
    }
}
