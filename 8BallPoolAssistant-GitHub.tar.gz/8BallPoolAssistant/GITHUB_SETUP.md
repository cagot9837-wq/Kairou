# Setup GitHub com GitHub Actions

## 🚀 Passo 1: Crie um Repositório no GitHub

1. Acesse https://github.com/new
2. Crie um novo repositório chamado `8BallPoolAssistant`
3. **NÃO** inicialize com README, .gitignore ou licença (já temos)
4. Clique em "Create repository"

## 📝 Passo 2: Configure Localmente

```bash
# Clone o repositório vazio
cd ~/seu-local
git clone https://github.com/SEU_USERNAME/8BallPoolAssistant.git
cd 8BallPoolAssistant

# Copie os arquivos do projeto pra cá
# Extraia o tar.gz e copie tudo

# Ou, se já tem o projeto:
cd 8BallPoolAssistant

# Inicialize o git
git init
git add .
git commit -m "Initial commit: 8 Ball Pool Assistant app"
git branch -M main
git remote add origin https://github.com/SEU_USERNAME/8BallPoolAssistant.git
git push -u origin main
```

## 🔑 Passo 3: Configure GitHub Actions

Os workflows estão em `.github/workflows/build.yml` e vão rodar automaticamente quando você fizer push.

### O que acontece no workflow:

1. **Setup JDK 11** — instala Java
2. **Build Debug APK** — compila versão debug
3. **Build Release APK** — compila versão release
4. **Upload Artifacts** — salva os APKs na aba "Actions"

## ✅ Passo 4: Faça Push

```bash
git add .
git commit -m "feat: add GitHub Actions workflow"
git push origin main
```

Vá para https://github.com/SEU_USERNAME/8BallPoolAssistant/actions e acompanhe a build.

## 📦 Passo 5: Baixe os APKs

Quando a build terminar com sucesso:

1. Acesse a workflow run
2. Clique em "Artifacts" no topo
3. Download `debug-apk` ou `release-apk`
4. Extraia e instale no seu Android:

```bash
# Via adb
adb install -r app-debug.apk
```

## 🔄 Releases Automáticas

Para criar uma release com APK:

```bash
# Tag a versão
git tag -a v1.0.0 -m "Release version 1.0.0"
git push origin v1.0.0
```

O workflow vai:
1. Compilar automaticamente
2. Criar uma release no GitHub
3. Fazer upload dos APKs

## 🛠️ Troubleshooting GitHub Actions

### Build falhou?

1. Vá em "Actions" > workflow com erro
2. Clique no job "build"
3. Expanda "Build APK Debug/Release"
4. Veja os logs de erro

### Erros comuns:

**"Could not find gradle"**
- Certifique-se que `gradlew` está no repo com permissão de execução
- Run: `chmod +x gradlew` localmente e faça push

**"Gradle build failed"**
- Rode localmente: `./gradlew build`
- Verifique se `build.gradle.kts` está correto
- Teste com versão debug antes

**"Task 'build' not found"**
- Verifique `settings.gradle.kts`
- Certifique-se que `app/` existe com o `build.gradle.kts`

## 📊 Monitorar Builds

Acesse: https://github.com/SEU_USERNAME/8BallPoolAssistant/actions

Você verá:
- Status de cada build
- Duração
- Artifacts gerados
- Logs detalhados

## 🔐 Segurança

O workflow usa `GITHUB_TOKEN` automático (nenhuma configuração necessária).

Para adicionar secrets (ex: chaves de signing):
1. Settings > Secrets and variables > Actions
2. Click "New repository secret"
3. Adicione a chave (ex: `SIGNING_KEY_PASSWORD`)
4. Use no workflow com `${{ secrets.SIGNING_KEY_PASSWORD }}`

## 📱 Instalação no Android

Depois de baixar os APKs:

### Via ADB (recomendado)
```bash
adb devices  # Verifique se seu device está listado
adb install -r app-debug.apk
```

### Manual
1. Copie o APK pra uma pasta acessível do Android
2. Abra um file manager no seu phone
3. Toque no APK
4. Clique "Instalar"
5. Conceda permissões quando solicitado

## 🚀 Próximos Passos

1. Edite o código localmente
2. Faça commits
3. Push para GitHub
4. GitHub Actions compila automaticamente
5. Baixe o APK e teste

```bash
# Workflow padrão
git add .
git commit -m "feature: improve ball detection"
git push origin main
# → GitHub Actions começa a compilar
# → Você pode ver o status em Actions
# → Download os APKs quando terminar
```

## 💡 Dicas

- Teste localmente com `./gradlew build` antes de fazer push
- Use branches para desenvolvimento: `git checkout -b feature/meu-recurso`
- Faça PRs pra integrar features: `git push origin feature/meu-recurso`

---

**Seu projeto está configurado pra CI/CD automático! 🎉**
