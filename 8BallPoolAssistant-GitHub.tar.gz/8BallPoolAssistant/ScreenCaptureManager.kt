package com.ballpool.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.content.Intent

class ScreenCaptureManager(private val context: Context) {

    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private var onFrame: ((Bitmap) -> Unit)? = null

    fun startCapture(
        resultCode: Int,
        data: Intent,
        onFrame: (Bitmap) -> Unit
    ) {
        this.onFrame = onFrame

        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = manager.getMediaProjection(resultCode, data)

        val metrics = context.resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "8BallCapture",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, null
        )

        setupImageListener(width, height)
    }

    private fun setupImageListener(width: Int, height: Int) {
        imageReader?.setOnImageAvailableListener(
            { reader ->
                try {
                    val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener

                    val planes = image.planes
                    val buffer = planes[0].buffer
                    val pixelStride = planes[0].pixelStride
                    val rowStride = planes[0].rowStride
                    val rowPadding = rowStride - pixelStride * width

                    val bitmap = Bitmap.createBitmap(
                        width + rowPadding / pixelStride,
                        height,
                        Bitmap.Config.ARGB_8888
                    )
                    bitmap.copyPixelsFromBuffer(buffer)

                    val croppedBitmap = Bitmap.createBitmap(bitmap, 0, 0, width, height)

                    image.close()
                    bitmap.recycle()

                    onFrame?.invoke(croppedBitmap)

                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            Handler(Looper.getMainLooper())
        )
    }

    fun stop() {
        virtualDisplay?.release()
        mediaProjection?.stop()
        imageReader?.close()
        mediaProjection = null
        imageReader = null
        virtualDisplay = null
    }
}
