package com.ballpool.assistant

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

data class Ball(
    val center: Point,
    val radius: Double,
    val color: BallColor
)

enum class BallColor { WHITE, SOLID, STRIPED, BLACK, UNKNOWN }

class BallDetector {

    fun detect(bitmap: Bitmap): List<Ball> {
        return try {
            val mat = Mat()
            Utils.bitmapToMat(bitmap, mat)

            val gray = Mat()
            Imgproc.cvtColor(mat, gray, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.GaussianBlur(gray, gray, Size(9.0, 9.0), 2.0)

            val circles = Mat()
            Imgproc.HoughCircles(
                gray, circles,
                Imgproc.HOUGH_GRADIENT,
                1.0,
                30.0,
                100.0,
                30.0,
                8,
                50
            )

            val balls = mutableListOf<Ball>()

            if (circles.cols() > 0) {
                for (i in 0 until circles.cols()) {
                    val data = circles.get(0, i)
                    val center = Point(data[0], data[1])
                    val radius = data[2]
                    val color = classifyBallColor(mat, center, radius)

                    balls.add(Ball(center, radius, color))
                }
            }

            mat.release()
            gray.release()
            circles.release()

            balls.sortedByDescending { it.radius }

        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    private fun classifyBallColor(mat: Mat, center: Point, radius: Double): BallColor {
        return try {
            val x = (center.x - radius).toInt().coerceAtLeast(0)
            val y = (center.y - radius).toInt().coerceAtLeast(0)
            val size = (radius * 2).toInt().coerceAtMost(mat.width().coerceAtMost(mat.height()))

            if (x + size > mat.width() || y + size > mat.height()) {
                return BallColor.UNKNOWN
            }

            val roi = Mat(mat, Rect(x, y, size, size))
            val hsv = Mat()
            Imgproc.cvtColor(roi, hsv, Imgproc.COLOR_RGBA2HSV)

            val meanColor = Core.mean(hsv)
            val hue = meanColor.`val`[0]
            val saturation = meanColor.`val`[1]
            val value = meanColor.`val`[2]

            val color = when {
                value > 200 && saturation < 50 -> BallColor.WHITE
                value < 80 -> BallColor.BLACK
                saturation < 40 -> BallColor.WHITE
                hue in 0.0..30.0 || hue in 330.0..360.0 -> BallColor.SOLID
                else -> BallColor.STRIPED
            }

            roi.release()
            hsv.release()

            color

        } catch (e: Exception) {
            e.printStackTrace()
            BallColor.UNKNOWN
        }
    }
}
